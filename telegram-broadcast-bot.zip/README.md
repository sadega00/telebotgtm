# Telegram Bot di Render
Bot Telegram sederhana yang berjalan 24/7 di Render.

## Deploy
1. Upload project ini ke GitHub
2. Buka Render → New → Web Service
3. Pilih repo ini
4. Build Command: pip install -r requirements.txt
5. Start Command: python main.py
6. Tambahkan Environment Variable: BOT_TOKEN = <8492055154:AAGgkRmXHW4KSxQ4Uh__vBpbQM5LNSPkZnI>
7. Deploy 🚀
